nazev: "meetingBesidka" - bez podpisu
       "meetingBesidka1" - s podpisem

autor:      Bumper/MRS
         Frantisek Brablc
      email: bumper@volny.cz

compo: 2D grafika

vyhru prevezme: Bomber / MRS

note:
 obrazek je urcen pro pripravovane slide show
 ze setkani demogrupy MaRshalS online,ktere 
 melo kodovy nazev Besidka :)
