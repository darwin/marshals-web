nazev: "Pharmacy" - bez podpisu

autor:      Jupiter/MRS

compo: rendered gfx

vyhru prevezme: Bomber / MRS
